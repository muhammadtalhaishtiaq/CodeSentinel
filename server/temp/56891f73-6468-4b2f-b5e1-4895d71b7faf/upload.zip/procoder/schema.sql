CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
);

CREATE TABLE sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid TEXT UNIQUE NOT NULL,
    chat_history TEXT NOT NULL,
    current_code TEXT,
    instructions TEXT,
    user_id INTEGER,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
);


CREATE TABLE session_conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user__id TEXT UNIQUE NOT NULL,
    session_id TEXT UNIQUE NOT NULL,
    chat_id TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL,
    content TEXT,
    ip_token TEXT,
    op_token INTEGER,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES sessions (id)
    FOREIGN KEY (user_id) REFERENCES users (id)
);